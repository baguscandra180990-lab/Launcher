@echo off
echo Gradle wrapper placeholder - use AndroidIDE built-in Gradle
