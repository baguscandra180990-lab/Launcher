
package com.ultra.iosfull;

import android.app.Activity;
import android.content.*;
import android.content.pm.*;
import android.os.Bundle;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {

    GridView grid;
    List<AppModel> apps;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);

        grid = new GridView(this);
        grid.setNumColumns(4);

        loadApps();

        grid.setAdapter(new AppAdapter(this, apps));

        grid.setOnItemClickListener((p,v,i,id)->{
            Intent launch = getPackageManager()
                .getLaunchIntentForPackage(apps.get(i).pkg);
            if(launch!=null) startActivity(launch);
        });

        setContentView(grid);
    }

    void loadApps(){
        apps = new ArrayList<>();
        Intent i = new Intent(Intent.ACTION_MAIN, null);
        i.addCategory(Intent.CATEGORY_LAUNCHER);

        List<ResolveInfo> r = getPackageManager().queryIntentActivities(i,0);

        for(ResolveInfo ri: r){
            apps.add(new AppModel(
                ri.loadLabel(getPackageManager()).toString(),
                ri.activityInfo.packageName,
                ri.loadIcon(getPackageManager())
            ));
        }
    }
}
