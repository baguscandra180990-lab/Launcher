
package com.ultra.iosfull;

import android.graphics.drawable.Drawable;

public class AppModel {
    String name;
    String pkg;
    Drawable icon;

    public AppModel(String n,String p,Drawable i){
        name=n; pkg=p; icon=i;
    }
}
